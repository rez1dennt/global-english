<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
$config = global_english_config();
$cities = ['Казань', 'Нижнекамск', 'Чебоксары', 'Екатеринбург'];
$advantages = [
    ['certificate', 'Образовательная лицензия'],
    ['book', 'Наши рабочие материалы'],
    ['checklist', 'Ежеквартальные тестирования'],
    ['globe', 'Занятия с носителями языка'],
    ['party', 'Праздничные мероприятия'],
    ['users', 'Мини-группы'],
    ['star', 'Система мотивации'],
    ['video', 'Дополнительные видеоуроки занятий'],
];
$pricePoints = [
    'Доступная стоимость абонементов',
    'Гибкая система скидок',
    'Бесплатное пробное занятие',
    'Можно оплатить обучение материнским капиталом',
    'Можно вернуть налоговый вычет 13% с покупки занятий',
];
get_header();
?>
<main id="main-content">
    <section class="hero" id="home" aria-labelledby="hero-title">
        <div class="container hero__inner">
            <div class="hero__copy">
                <p class="eyebrow"><span class="status-dot"></span> ШКОЛА ИНОСТРАННЫХ ЯЗЫКОВ</p>
                <h1 id="hero-title">Большой мир<br>начинается<br><em>с нового языка.</em></h1>
                <p class="hero__lead">Английский и китайский<br>для детей от <strong>7 до 17 лет</strong></p>
                <p class="hero__description">Учимся в вашей школе.<br>Без лишней дороги — с интересом к языкам.</p>
                <a class="button button--primary" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Записаться на бесплатное занятие <?php echo global_english_icon('arrow'); ?></a>
                <a class="hero__secondary" href="#about">Познакомиться со школой <span aria-hidden="true">↓</span></a>
                <div class="hero__languages" aria-label="Английский и китайский языки"><span><b>EN</b> Английский</span><span><b>中文</b> Китайский</span></div>
            </div>
            <div class="hero__visual">
                <div class="hero__photo"><img src="<?php echo esc_url(get_theme_file_uri('/assets/images/hero-school.webp')); ?>" alt="Мальчик с книгой — иллюстрация школы Global English" width="960" height="1200" fetchpriority="high"></div>
                <span class="hello hello--english" aria-hidden="true">Hello! <span>✦</span></span>
                <span class="hello hello--chinese" aria-hidden="true">你好! <small>Привет, новый мир</small></span>
                <div class="hero__trial-tag"><?php echo global_english_icon('gift'); ?><span>Первое занятие<br><strong>бесплатно</strong></span></div>
                <svg class="hero__orbit" viewBox="0 0 160 100" fill="none" aria-hidden="true"><path d="M4 77C50 8 129 4 143 42c15 39-50 53-45 18 3-19 38-36 57-44m-17 0h18l-4 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-dasharray="5 7"/></svg>
            </div>
        </div>
    </section>

    <section class="city-band" id="branches" aria-labelledby="branches-title">
        <div class="container city-band__inner">
            <div><p class="eyebrow">НАШИ ФИЛИАЛЫ</p><h2 id="branches-title">Мы работаем<br>в четырёх городах</h2></div>
            <ul class="city-list"><?php foreach ($cities as $i => $city) : ?><li><span class="city-list__number"><?php echo esc_html('0' . ($i + 1)); ?></span><?php echo global_english_icon('pin'); ?><strong><?php echo esc_html($city); ?></strong></li><?php endforeach; ?></ul>
        </div>
    </section>

    <section class="section about" id="about" aria-labelledby="about-title">
        <div class="container">
            <div class="section-intro" data-reveal>
                <div><p class="eyebrow">БЛИЖЕ, ЧЕМ КАЖЕТСЯ</p><h2 id="about-title">Наши занятия проходят<br><span>в вашей школе</span></h2></div>
                <p>Не нужно тратить время на дорогу для получения знаний по английскому и китайскому языку.<br><strong>Занятия для детей от 7 до 17 лет.</strong></p>
            </div>
            <div class="learning-path">
                <article class="path-step" data-reveal><span class="path-step__number">01</span><div class="path-step__icon"><?php echo global_english_icon('school'); ?></div><h3>Знакомое место</h3><p>Ребёнок приходит в свою школу.</p></article>
                <article class="path-step" data-reveal><span class="path-step__number">02</span><div class="path-step__icon"><?php echo global_english_icon('globe'); ?></div><h3>Новые возможности</h3><p>Изучает английский или китайский язык.</p></article>
                <article class="path-step" data-reveal><span class="path-step__number">03</span><div class="path-step__icon"><?php echo global_english_icon('heart'); ?></div><h3>Удобно всей семье</h3><p>Без дополнительных поездок на занятия.</p></article>
            </div>
            <div class="section-action"><a class="button button--outline" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Попробовать бесплатно <?php echo global_english_icon('arrow'); ?></a><p>Уточним, в каких школах вашего города проходят занятия.</p></div>
        </div>
    </section>

    <section class="section benefits" id="benefits" aria-labelledby="benefits-title">
        <div class="container">
            <div class="section-intro" data-reveal><div><p class="eyebrow">УЧИТЬСЯ С ИНТЕРЕСОМ</p><h2 id="benefits-title">Наши преимущества</h2></div><p>Мы всегда работаем над тем, чтобы наше обучение становилось более эффективным и увлекательным.</p></div>
            <div class="benefit-grid"><?php foreach ($advantages as $i => [$icon, $label]) : ?><article class="benefit-card" data-reveal><span class="benefit-card__number"><?php echo esc_html('0' . ($i + 1)); ?></span><div class="benefit-card__icon"><?php echo global_english_icon($icon); ?></div><h3><?php echo esc_html($label); ?></h3></article><?php endforeach; ?></div>
        </div>
    </section>

    <section class="section teachers" id="teachers" aria-labelledby="teachers-title">
        <div class="container">
            <div class="section-intro" data-reveal><div><p class="eyebrow">ЛЮДИ, КОТОРЫЕ ВДОХНОВЛЯЮТ</p><h2 id="teachers-title">Наши педагоги</h2></div><p>Все наши педагоги имеют высшее педагогическое образование и опыт работы с детьми. Также каждый педагог проходит дополнительное обучение в соответствии с нашей программой.</p></div>
            <article class="director" data-reveal>
                <div class="director__portrait">
                    <?php $directorPhoto = global_english_client_image((string) $config['director_photo']); if ($directorPhoto !== '') : ?>
                    <img src="<?php echo esc_url($directorPhoto); ?>" alt="Борисова Глория Гариевна" loading="lazy" width="600" height="700">
                    <?php else : ?><img class="director__brand" src="<?php echo esc_url(get_theme_file_uri('/assets/icons/brand.svg')); ?>" alt="" width="160" height="160"><span class="director__initials" aria-hidden="true">ГБ</span><span class="director__portrait-note">GLOBAL ENGLISH<br>LANGUAGE SCHOOL</span><?php endif; ?>
                </div>
                <div class="director__content">
                    <p class="eyebrow">ДАВАЙТЕ ЗНАКОМИТЬСЯ</p><h3>Борисова<br>Глория Гариевна</h3>
                    <p class="director__role">Руководитель Школы Global English</p>
                    <div class="director__experience"><strong>14<span>+</span></strong><p>Опыт работы с детьми<br><b>более 14 лет</b></p></div>
                    <p class="director__message">Вы можете обратиться ко мне<br>по любым вопросам.</p>
                    <a class="button button--light" href="<?php echo esc_url(global_english_director_url()); ?>" target="_blank" rel="noopener noreferrer"><?php echo global_english_icon('telegram'); ?> Написать Глории <?php echo global_english_icon('arrow'); ?></a>
                    <span class="director__handle">@gloriabuava_english</span>
                </div>
            </article>
            <?php if (!empty($config['teacher_photos'])) : ?><div class="team-gallery"><?php foreach ($config['teacher_photos'] as $photo) : $photoUrl = global_english_client_image((string) $photo); if ($photoUrl === '') { continue; } ?><img src="<?php echo esc_url($photoUrl); ?>" alt="Педагог школы Global English" width="480" height="600" loading="lazy"><?php endforeach; ?></div><?php else : ?><p class="content-note"><?php echo global_english_icon('users'); ?> Фотографии команды будут добавлены здесь.</p><?php endif; ?>
        </div>
    </section>

    <section class="section reviews" id="reviews" aria-labelledby="reviews-title">
        <div class="container">
            <div class="section-intro" data-reveal><div><p class="eyebrow">ВАЖНО КАЖДОЕ МНЕНИЕ</p><h2 id="reviews-title">Отзывы</h2></div><p>Мы собираем обратную связь,<br>чтобы становиться лучше для вас.</p></div>
            <?php if (!empty($config['reviews'])) : ?><div class="review-grid"><?php foreach ($config['reviews'] as $review) : ?><figure class="review-card"><?php echo global_english_icon('quote'); ?><blockquote><?php echo esc_html((string) $review['text']); ?></blockquote><figcaption><?php echo esc_html((string) $review['author']); ?></figcaption></figure><?php endforeach; ?></div>
            <?php else : ?><div class="review-empty" data-reveal><div class="review-empty__mark"><?php echo global_english_icon('quote'); ?></div><div><h3>Ваша обратная связь<br>помогает нам расти</h3><p>Отзывы будут опубликованы после добавления материалов от школы.</p></div><a class="text-link" href="<?php echo esc_url(global_english_director_url()); ?>" target="_blank" rel="noopener noreferrer">Поделиться впечатлениями <?php echo global_english_icon('arrow'); ?></a></div><?php endif; ?>
        </div>
    </section>

    <section class="section prices" id="prices" aria-labelledby="prices-title">
        <div class="container price-layout">
            <div data-reveal><p class="eyebrow">ВКЛАД В БОЛЬШОЙ МИР</p><h2 id="prices-title">Стоимость наших занятий</h2><ul class="price-points"><?php foreach ($pricePoints as $point) : ?><li><?php echo global_english_icon('check'); ?><span><?php echo esc_html($point); ?></span></li><?php endforeach; ?></ul><p class="price-note">Условия оплаты материнским капиталом и получения налогового вычета уточняйте у администратора.</p></div>
            <div class="price-card" data-reveal><span class="price-card__icon"><?php echo global_english_icon('gift'); ?></span><p class="eyebrow">ПЕРВЫЙ ШАГ — БЕСПЛАТНО</p><h3>Начнём<br>со знакомства?</h3><p>Приходите на пробное занятие<br>по английскому или китайскому.</p><a class="button button--primary" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Записаться на пробное занятие <?php echo global_english_icon('arrow'); ?></a>
            <?php $priceUrl = global_english_document_url('price'); if ($priceUrl !== '') : ?><a class="text-link" href="<?php echo esc_url($priceUrl); ?>" target="_blank" rel="noopener">Посмотреть прайс-лист <?php echo global_english_icon('arrow'); ?></a><?php else : ?><details class="price-disclosure"><summary>Посмотреть прайс-лист <?php echo global_english_icon('chevron'); ?></summary><p>Файл прайс-листа ещё не добавлен. Уточните стоимость по телефону <a href="tel:<?php echo esc_attr(global_english_contact_phone()); ?>">+7 (960) 064-31-41</a>.</p></details><?php endif; ?>
            </div>
        </div>
    </section>

    <section class="contact-section" id="contacts" aria-labelledby="contact-title">
        <div class="container contact-panel">
            <div class="contact-panel__copy"><p class="eyebrow">ПРИВЕТ, GLOBAL ENGLISH!</p><h2 id="contact-title">Новый язык.<br>Новые открытия.<br><span>Начнём?</span></h2><p>Оставьте заявку на бесплатное пробное занятие. Мы свяжемся с вами в ближайшее время.</p><a class="contact-phone" href="tel:<?php echo esc_attr(global_english_contact_phone()); ?>"><?php echo global_english_icon('phone'); ?> +7 (960) 064-31-41</a><span class="contact-panel__languages" aria-hidden="true">Hello! <i>你好!</i></span></div>
            <div class="contact-form-card"><h3>Записаться на пробное занятие</h3><?php $formSource = 'inline'; include __DIR__ . '/template-parts/trial-form.php'; ?></div>
        </div>
    </section>
</main>

<div class="enrollment-modal" id="enrollment-modal" data-enrollment-modal data-state="closed" aria-hidden="true" inert>
    <div class="enrollment-modal__backdrop" data-modal-backdrop></div>
    <section class="enrollment-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="enrollment-modal-title" aria-describedby="enrollment-modal-description" data-modal-dialog tabindex="-1">
        <button class="enrollment-modal__close" type="button" aria-label="Закрыть форму записи" data-modal-close><svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M5 5l14 14M19 5 5 19"/></svg></button>
        <div class="enrollment-modal__header"><p class="eyebrow">ДАВАЙТЕ ЗНАКОМИТЬСЯ</p><h2 id="enrollment-modal-title">Первое занятие —<br><span>бесплатно</span></h2><p id="enrollment-modal-description">Оставьте контакты — мы свяжемся с вами в ближайшее время.</p></div>
        <?php $formSource = 'modal'; include __DIR__ . '/template-parts/trial-form.php'; ?>
    </section>
</div>
<?php get_footer(); ?>
