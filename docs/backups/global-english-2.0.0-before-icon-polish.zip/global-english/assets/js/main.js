(function () {
    'use strict';

    document.documentElement.classList.add('js');

    function focusableElements(container) {
        return Array.from(container.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'));
    }

    function initMenu(scrollLock) {
        var toggle = document.querySelector('[data-menu-toggle]');
        var panel = document.querySelector('[data-menu-panel]');
        if (!toggle || !panel) {
            return;
        }

        var scrollPosition = 0;
        var closeTimer = 0;

        function isMobileMenu() {
            return window.matchMedia('(max-width: 60rem)').matches;
        }

        function setClosedState() {
            panel.dataset.state = 'closed';
            if (isMobileMenu()) {
                panel.inert = true;
                panel.setAttribute('aria-hidden', 'true');
            } else {
                panel.inert = false;
                panel.setAttribute('aria-hidden', 'false');
            }
        }

        function openMenu() {
            window.clearTimeout(closeTimer);
            scrollPosition = scrollLock ? scrollLock.lock() : window.scrollY;
            toggle.setAttribute('aria-expanded', 'true');
            toggle.setAttribute('aria-label', 'Закрыть меню');
            panel.dataset.state = 'open';
            panel.inert = false;
            panel.setAttribute('aria-hidden', 'false');
            if (!scrollLock) {
                document.body.style.top = '-' + scrollPosition + 'px';
                document.body.classList.add('menu-open');
            }
            var focusable = focusableElements(panel);
            if (focusable[0]) {
                focusable[0].focus();
            }
        }

        function closeMenu(returnFocus) {
            if (toggle.getAttribute('aria-expanded') !== 'true') {
                return;
            }
            toggle.setAttribute('aria-expanded', 'false');
            toggle.setAttribute('aria-label', 'Открыть меню');
            panel.dataset.state = 'closing';
            panel.inert = true;
            panel.setAttribute('aria-hidden', 'true');
            if (scrollLock) {
                scrollLock.unlock();
            } else {
                document.body.classList.remove('menu-open');
                document.body.style.top = '';
                window.scrollTo({ top: scrollPosition, left: 0, behavior: 'instant' });
            }
            closeTimer = window.setTimeout(setClosedState, 360);
            if (returnFocus) {
                toggle.focus({ preventScroll: true });
            }
        }

        toggle.addEventListener('click', function () {
            if (toggle.getAttribute('aria-expanded') === 'true') {
                closeMenu(false);
            } else {
                openMenu();
            }
        });

        panel.addEventListener('click', function (event) {
            if (event.target.closest('a[href^="#"]')) {
                closeMenu(false);
            }
        });

        document.addEventListener('pointerdown', function (event) {
            if (toggle.getAttribute('aria-expanded') === 'true' && !panel.contains(event.target) && !toggle.contains(event.target)) {
                closeMenu(false);
            }
        });

        document.addEventListener('keydown', function (event) {
            if (toggle.getAttribute('aria-expanded') !== 'true') {
                return;
            }
            if (event.key === 'Escape') {
                event.preventDefault();
                closeMenu(true);
                return;
            }
            if (event.key !== 'Tab') {
                return;
            }
            var focusable = [toggle].concat(focusableElements(panel));
            var first = focusable[0];
            var last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });

        window.addEventListener('resize', function () {
            if (window.innerWidth > 960) {
                closeMenu(false);
                setClosedState();
            } else if (toggle.getAttribute('aria-expanded') !== 'true') {
                setClosedState();
            }
        });

        setClosedState();
    }

    function initSmoothAnchors() {
        document.addEventListener('click', function (event) {
            if (event.defaultPrevented) {
                return;
            }
            var link = event.target.closest('a[href^="#"]');
            if (!link) {
                return;
            }
            var selector = link.getAttribute('href');
            if (!selector || selector === '#') {
                return;
            }
            var target = document.querySelector(selector);
            if (!target) {
                return;
            }
            event.preventDefault();
            var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
            window.setTimeout(function () {
                target.setAttribute('tabindex', '-1');
                target.focus({ preventScroll: true });
                target.addEventListener('blur', function cleanup() {
                    target.removeAttribute('tabindex');
                }, { once: true });
            }, reduceMotion ? 0 : 420);
        });
    }

    function initPhoneMask() {
        var phone = window.GlobalEnglishPhone;
        var inputs = document.querySelectorAll('[data-phone-input]');
        if (!phone || !inputs.length) {
            return;
        }

        inputs.forEach(function (input) {
            input.addEventListener('beforeinput', function (event) {
                if (event.inputType === 'insertFromPaste' || event.isComposing) {
                    return;
                }
                if (!event.inputType.startsWith('insert') && !event.inputType.startsWith('delete')) {
                    return;
                }
                event.preventDefault();
                var result = phone.editRussianPhone(
                    input.value,
                    input.selectionStart || 0,
                    input.selectionEnd || 0,
                    event.inputType,
                    event.data || ''
                );
                input.value = result.value;
                input.setSelectionRange(result.caret, result.caret);
                input.dispatchEvent(new Event('maskchange', { bubbles: true }));
            });

            input.addEventListener('paste', function (event) {
                event.preventDefault();
                var text = event.clipboardData ? event.clipboardData.getData('text') : '';
                var result = phone.editRussianPhone(
                    input.value,
                    input.selectionStart || 0,
                    input.selectionEnd || 0,
                    'insertText',
                    text
                );
                input.value = result.value;
                input.setSelectionRange(result.caret, result.caret);
                input.dispatchEvent(new Event('maskchange', { bubbles: true }));
            });

            input.addEventListener('input', function () {
                var formatted = phone.formatRussianPhone(input.value);
                if (formatted !== input.value) {
                    input.value = formatted;
                }
            });
        });
    }

    function setFieldError(field, message) {
        var errorId = field.getAttribute('aria-describedby');
        var error = errorId ? document.getElementById(errorId) : null;
        field.setAttribute('aria-invalid', message ? 'true' : 'false');
        if (error) {
            error.textContent = message;
        }
    }

    function initForm() {
        var forms = document.querySelectorAll('[data-trial-form]');
        if (!forms.length) {
            return;
        }

        forms.forEach(function (form) {
            initFormInstance(form);
        });
    }

    function initFormInstance(form) {

        var name = form.elements.name;
        var phoneInput = form.elements.phone;
        var consent = form.elements.consent;
        var submit = form.querySelector('[type="submit"]');
        var status = form.querySelector('[data-form-status]');
        var phone = window.GlobalEnglishPhone;

        var statusMessages = {
            demo: ['success', 'Предпросмотр: данные проверены, письмо не отправлено.'],
            success: ['success', 'Заявка отправлена. Мы свяжемся с вами в ближайшее время.'],
            validation_error: ['error', 'Проверьте данные формы и отправьте заявку ещё раз.'],
            rate_limited: ['error', 'Заявка уже отправлена. Подождите минуту перед повторной отправкой.'],
            mail_error: ['error', 'Не удалось отправить заявку. Позвоните нам по телефону.'],
            security_error: ['error', 'Страница устарела. Обновите её и повторите отправку.'],
            invalid_request: ['error', 'Не удалось обработать запрос. Обновите страницу.'],
        };
        var serverStatus = new URLSearchParams(window.location.search).get('form_status');
        var serverSource = new URLSearchParams(window.location.search).get('form_source') || 'inline';
        var formSource = form.dataset.formSource || 'inline';
        if (serverStatus && statusMessages[serverStatus] && serverSource === formSource) {
            status.dataset.status = statusMessages[serverStatus][0];
            status.textContent = statusMessages[serverStatus][1];
        }

        [name, phoneInput, consent].forEach(function (field) {
            field.addEventListener('input', function () {
                setFieldError(field, '');
            });
            field.addEventListener('change', function () {
                setFieldError(field, '');
            });
        });

        form.addEventListener('submit', function (event) {
            var firstInvalid = null;
            var nameValue = name.value.trim();

            if (Array.from(nameValue).length < 2 || Array.from(nameValue).length > 80) {
                setFieldError(name, 'Укажите имя от 2 до 80 символов.');
                firstInvalid = firstInvalid || name;
            } else {
                setFieldError(name, '');
            }

            if (!phone || !phone.isValidRussianPhone(phoneInput.value)) {
                setFieldError(phoneInput, 'Введите телефон полностью: +7 (999) 999-99-99.');
                firstInvalid = firstInvalid || phoneInput;
            } else {
                setFieldError(phoneInput, '');
            }

            if (!consent.checked) {
                setFieldError(consent, 'Подтвердите согласие на обработку данных.');
                firstInvalid = firstInvalid || consent;
            } else {
                setFieldError(consent, '');
            }

            if (firstInvalid) {
                event.preventDefault();
                status.dataset.status = 'error';
                status.textContent = 'Исправьте отмеченные поля.';
                firstInvalid.focus();
                return;
            }

            submit.disabled = true;
            submit.setAttribute('aria-busy', 'true');
            submit.textContent = 'Отправляем...';
            status.textContent = '';
        });
    }

    function initTeacherSlider() {
        var slider = document.querySelector('[data-teacher-slider]');
        if (!slider) {
            return;
        }
        var track = slider.querySelector('[data-slider-track]');
        var previous = slider.querySelector('[data-slider-prev]');
        var next = slider.querySelector('[data-slider-next]');
        var status = document.getElementById('teacher-slider-status');

        function update() {
            var maxScroll = Math.max(0, track.scrollWidth - track.clientWidth);
            previous.disabled = track.scrollLeft <= 2;
            next.disabled = track.scrollLeft >= maxScroll - 2;
        }

        function move(direction) {
            var card = track.querySelector('.teacher-card');
            var amount = card ? card.getBoundingClientRect().width + 20 : track.clientWidth;
            track.scrollBy({ left: amount * direction, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
            if (status) {
                status.textContent = direction > 0 ? 'Показаны следующие преподаватели' : 'Показаны предыдущие преподаватели';
            }
        }

        previous.addEventListener('click', function () { move(-1); });
        next.addEventListener('click', function () { move(1); });
        track.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', update);
        update();
    }

    function initReveal() {
        var elements = document.querySelectorAll('[data-reveal]');
        if (!elements.length) {
            return;
        }
        if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            elements.forEach(function (element) { element.dataset.revealed = 'true'; });
            return;
        }
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.dataset.revealed = 'true';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -5% 0px' });
        elements.forEach(function (element, index) {
            element.style.setProperty('--reveal-index', String(index % 4));
            observer.observe(element);
        });
    }

    function init() {
        var scrollLock = window.GlobalEnglishScrollLock
            ? window.GlobalEnglishScrollLock.getSharedScrollLock(window, document)
            : null;
        initMenu(scrollLock);
        initSmoothAnchors();
        initPhoneMask();
        initForm();
        initTeacherSlider();
        initReveal();
        if (window.GlobalEnglishModal) {
            window.GlobalEnglishModal.initEnrollmentModal({ scrollLock: scrollLock });
        }
        if (window.GlobalEnglishCookie) {
            window.GlobalEnglishCookie.initCookieConsent();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
}());
