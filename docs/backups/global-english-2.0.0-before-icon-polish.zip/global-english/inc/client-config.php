<?php
// Add only verified client materials. Paths are theme-relative; URLs must be https.
return [
    'max_url' => '',
    'whatsapp_url' => '',
    'director_photo' => '',
    'teacher_photos' => [],
    'reviews' => [], // Each record: ['text' => 'Approved quote', 'author' => 'Approved display name'].
];
