<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$asset = static fn(string $path): string => esc_url(get_theme_file_uri('/assets/' . ltrim($path, '/')));

$courses = [
    ['icon' => 'big-ben.svg', 'title' => 'Английский для начинающих', 'level' => 'A1 - A2'],
    ['icon' => 'crown.svg', 'title' => 'Английский для продолжающих', 'level' => 'B1 - B2'],
    ['icon' => 'graduation-cap.svg', 'title' => 'Подготовка к IELTS / TOEFL', 'level' => 'B2 - C1'],
    ['icon' => 'pagoda.svg', 'title' => 'Китайский язык для всех уровней', 'level' => 'HSK 1 - 6'],
];

$benefits = [
    ['icon' => 'users.svg', 'title' => 'Опытные преподаватели', 'text' => 'Носители языка и дипломированные специалисты с опытом работы'],
    ['icon' => 'book-open.svg', 'title' => 'Современные методики', 'text' => 'Интерактивные занятия и актуальные учебные материалы'],
    ['icon' => 'trophy.svg', 'title' => 'Реальные результаты', 'text' => 'Тысячи учеников достигли своих целей вместе с нами'],
    ['icon' => 'clock.svg', 'title' => 'Удобный формат', 'text' => 'Гибкое расписание и занятия онлайн или офлайн'],
];

$methodItems = [
    ['icon' => 'messages.svg', 'title' => 'Коммуникативный подход', 'text' => 'Говорим с первого занятия'],
    ['icon' => 'book-check.svg', 'title' => 'Погружение в язык', 'text' => 'Живые диалоги и практика'],
    ['icon' => 'route.svg', 'title' => 'Индивидуальный план', 'text' => 'Программа под цели и уровень ученика'],
    ['icon' => 'flask.svg', 'title' => 'Контроль прогресса', 'text' => 'Регулярная оценка и обратная связь'],
];

$opportunities = [
    ['icon' => 'plane.svg', 'title' => 'Путешествуйте без границ', 'text' => 'Общайтесь в любой точке мира'],
    ['icon' => 'briefcase.svg', 'title' => 'Постройте карьеру мечты', 'text' => 'Знание языков даёт конкурентное преимущество'],
    ['icon' => 'university.svg', 'title' => 'Поступайте в топовые вузы', 'text' => 'Образование за рубежом становится ближе'],
    ['icon' => 'passport.svg', 'title' => 'Расширяйте кругозор', 'text' => 'Новые культуры, друзья и возможности'],
];

$stats = [
    ['icon' => 'medal.svg', 'value' => '8+', 'label' => 'лет опыта'],
    ['icon' => 'students.svg', 'value' => '1500+', 'label' => 'довольных учеников'],
    ['icon' => 'teacher.svg', 'value' => '20+', 'label' => 'преподавателей'],
    ['icon' => 'certificate.svg', 'value' => '95%', 'label' => 'рекомендуют нас'],
];

$teachers = [
    ['image' => 'teacher-anna.webp', 'name' => 'Anna Smith', 'role' => 'Преподаватель английского языка'],
    ['image' => 'teacher-li.webp', 'name' => 'Li Wei', 'role' => 'Преподаватель китайского языка'],
    ['image' => 'teacher-michael.webp', 'name' => 'Michael Brown', 'role' => 'Преподаватель английского языка'],
    ['image' => 'teacher-zhang.webp', 'name' => 'Zhang Min', 'role' => 'Преподаватель китайского языка'],
];

$reviews = [
    ['text' => 'Отличная школа! Изучала английский и сдала IELTS на нужный балл. Очень благодарна преподавателям!', 'author' => 'Дмитрий, 21 год'],
    ['text' => 'Занятия по китайскому языку проходят интересно и эффективно. Уже сдала HSK 4! Рекомендую Global English.', 'author' => 'Мария, 19 лет'],
    ['text' => 'Удобное расписание и классная атмосфера. Ребёнок с удовольствием ходит на уроки английского.', 'author' => 'Елена, мама ученика'],
];

$formStatus = isset($_GET['form_status']) ? sanitize_key(wp_unslash($_GET['form_status'])) : '';
$formMessages = [
    'success' => ['success', 'Заявка отправлена. Мы свяжемся с вами в ближайшее время.'],
    'validation_error' => ['error', 'Проверьте данные формы и отправьте заявку ещё раз.'],
    'rate_limited' => ['error', 'Заявка уже отправлена. Подождите минуту перед повторной отправкой.'],
    'mail_error' => ['error', 'Не удалось отправить заявку. Позвоните нам по телефону.'],
    'security_error' => ['error', 'Страница устарела. Обновите её и повторите отправку.'],
    'invalid_request' => ['error', 'Не удалось обработать запрос. Обновите страницу.'],
];
$formMessage = $formMessages[$formStatus] ?? null;
$formSource = isset($_GET['form_source']) && sanitize_key(wp_unslash($_GET['form_source'])) === 'modal' ? 'modal' : 'inline';
$inlineFormMessage = $formSource === 'inline' ? $formMessage : null;
$modalFormMessage = $formSource === 'modal' ? $formMessage : null;
?>

<main id="main-content">
    <section class="hero" id="about" aria-labelledby="hero-title">
        <img class="hero__backdrop" src="<?php echo $asset('images/hero-landmarks.webp'); ?>" alt="" width="2000" height="667" aria-hidden="true" fetchpriority="high">
        <div class="container hero__inner">
            <div class="hero__copy" data-reveal>
                <p class="eyebrow">GLOBAL ENGLISH</p>
                <h1 id="hero-title">АНГЛИЙСКИЙ<br><span>И КИТАЙСКИЙ</span> ЯЗЫКИ<br>ДЛЯ ВАШИХ ЦЕЛЕЙ</h1>
                <p class="hero__lead">Современное обучение с акцентом на результат.<br>Онлайн и офлайн занятия для детей и взрослых.</p>
                <div class="hero__actions">
                    <a class="button button--primary" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Попробовать бесплатно</a>
                    <a class="button button--secondary" href="#courses">Узнать больше <span aria-hidden="true">›</span></a>
                </div>
            </div>
            <div class="hero__visual" data-reveal>
                <span class="hero__sun" aria-hidden="true"></span>
                <img src="<?php echo $asset('images/hero-student.webp'); ?>" alt="Студентка языковой школы с учебниками" width="760" height="760" fetchpriority="high">
            </div>
        </div>
    </section>

    <section class="section courses" id="courses" aria-labelledby="courses-title">
        <div class="container">
            <h2 class="section-heading" id="courses-title">НАШИ КУРСЫ</h2>
            <div class="course-grid">
                <?php foreach ($courses as $course) : ?>
                    <article class="course-card card" data-reveal>
                        <span class="icon-disc"><img src="<?php echo $asset('icons/' . $course['icon']); ?>" alt="" width="54" height="54"></span>
                        <div class="course-card__content">
                            <h3><?php echo esc_html($course['title']); ?></h3>
                            <p><?php echo esc_html($course['level']); ?></p>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <div class="section-action"><a class="button button--outline" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Подобрать курс</a></div>
        </div>
    </section>

    <section class="section benefits" id="benefits" aria-labelledby="benefits-title">
        <div class="container">
            <h2 class="section-heading" id="benefits-title">ПОЧЕМУ ВЫБИРАЮТ НАС?</h2>
            <div class="benefit-grid">
                <?php foreach ($benefits as $benefit) : ?>
                    <article class="benefit-card" data-reveal>
                        <span class="icon-disc icon-disc--soft"><img src="<?php echo $asset('icons/' . $benefit['icon']); ?>" alt="" width="44" height="44"></span>
                        <h3><?php echo esc_html($benefit['title']); ?></h3>
                        <p><?php echo esc_html($benefit['text']); ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section method" id="method" aria-labelledby="method-title">
        <div class="container">
            <h2 class="section-heading" id="method-title">НАША МЕТОДИКА</h2>
            <div class="method__layout">
                <div class="method__media" data-reveal>
                    <img src="<?php echo $asset('images/method-online.webp'); ?>" alt="Ученица занимается английским онлайн с преподавателем" width="800" height="450" loading="lazy">
                </div>
                <div class="method__list">
                    <?php foreach ($methodItems as $item) : ?>
                        <article class="method-item" data-reveal>
                            <span class="method-item__icon"><img src="<?php echo $asset('icons/' . $item['icon']); ?>" alt="" width="28" height="28"></span>
                            <div><h3><?php echo esc_html($item['title']); ?></h3><p><?php echo esc_html($item['text']); ?></p></div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="section-action"><a class="button button--outline" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Попробовать методику</a></div>
        </div>
    </section>

    <section class="section opportunities" aria-labelledby="opportunities-title">
        <div class="container">
            <h2 class="section-heading" id="opportunities-title"><span>ИЗУЧЕНИЕ ЯЗЫКОВ</span> ОТКРЫВАЕТ ВОЗМОЖНОСТИ</h2>
            <div class="opportunities__layout">
                <div class="opportunity-list">
                    <?php foreach ($opportunities as $item) : ?>
                        <article class="opportunity-item" data-reveal>
                            <span class="method-item__icon"><img src="<?php echo $asset('icons/' . $item['icon']); ?>" alt="" width="28" height="28"></span>
                            <div><h3><?php echo esc_html($item['title']); ?></h3><p><?php echo esc_html($item['text']); ?></p></div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <div class="opportunity-gallery" data-reveal>
                    <img src="<?php echo $asset('images/opportunity-students.webp'); ?>" alt="Международная группа студентов" width="450" height="250" loading="lazy">
                    <img src="<?php echo $asset('images/opportunity-london.webp'); ?>" alt="Лондон с красным двухэтажным автобусом" width="450" height="250" loading="lazy">
                    <img src="<?php echo $asset('images/opportunity-china.webp'); ?>" alt="Традиционная китайская архитектура" width="450" height="250" loading="lazy">
                    <img src="<?php echo $asset('images/opportunity-study.webp'); ?>" alt="Студентка изучает китайский язык" width="450" height="250" loading="lazy">
                </div>
            </div>
            <div class="section-action"><a class="button button--primary" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Начать обучение</a></div>
        </div>
    </section>

    <section class="stats" aria-label="Школа в цифрах">
        <div class="container stats__inner">
            <?php foreach ($stats as $stat) : ?>
                <div class="stat">
                    <img src="<?php echo $asset('icons/' . $stat['icon']); ?>" alt="" width="42" height="42">
                    <div><strong><?php echo esc_html($stat['value']); ?></strong><span><?php echo esc_html($stat['label']); ?></span></div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="section teachers" id="teachers" aria-labelledby="teachers-title">
        <div class="container">
            <h2 class="section-heading" id="teachers-title">НАШИ ПРЕПОДАВАТЕЛИ</h2>
            <div class="teacher-carousel" role="region" aria-roledescription="carousel" aria-label="Преподаватели школы" data-teacher-slider>
                <button class="slider-button slider-button--prev" type="button" aria-label="Предыдущие преподаватели" data-slider-prev>
                    <img src="<?php echo $asset('icons/chevron-left.svg'); ?>" alt="" width="22" height="22">
                </button>
                <div class="teacher-track" data-slider-track>
                    <?php foreach ($teachers as $index => $teacher) : ?>
                        <article class="teacher-card card" role="group" aria-roledescription="слайд" aria-label="<?php echo esc_attr(($index + 1) . ' из ' . count($teachers)); ?>">
                            <img class="teacher-card__photo" src="<?php echo $asset('images/' . $teacher['image']); ?>" alt="<?php echo esc_attr($teacher['name'] . ', преподаватель Global English'); ?>" width="420" height="420" loading="lazy">
                            <div class="teacher-card__body"><h3><?php echo esc_html($teacher['name']); ?></h3><p><?php echo esc_html($teacher['role']); ?></p></div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <button class="slider-button slider-button--next" type="button" aria-label="Следующие преподаватели" data-slider-next>
                    <img src="<?php echo $asset('icons/chevron-right.svg'); ?>" alt="" width="22" height="22">
                </button>
                <p class="sr-only" id="teacher-slider-status" aria-live="polite"></p>
            </div>
        </div>
    </section>

    <section class="section reviews" id="reviews" aria-labelledby="reviews-title">
        <div class="container">
            <h2 class="section-heading" id="reviews-title">ОТЗЫВЫ НАШИХ УЧЕНИКОВ</h2>
            <div class="review-grid">
                <?php foreach ($reviews as $review) : ?>
                    <article class="review-card card" data-reveal>
                        <div class="rating" aria-label="Оценка: 5 из 5">
                            <?php for ($star = 0; $star < 5; $star++) : ?><img src="<?php echo $asset('icons/star.svg'); ?>" alt="" width="18" height="18"><?php endfor; ?>
                        </div>
                        <p><?php echo esc_html($review['text']); ?></p>
                        <strong><?php echo esc_html($review['author']); ?></strong>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="section classes" aria-labelledby="classes-title">
        <div class="container">
            <h2 class="section-heading" id="classes-title">НАШИ ЗАНЯТИЯ</h2>
            <div class="class-gallery" data-reveal>
                <?php for ($photo = 1; $photo <= 4; $photo++) : ?>
                    <img src="<?php echo $asset('images/class-0' . $photo . '.webp'); ?>" alt="Занятие в школе Global English" width="480" height="270" loading="lazy">
                <?php endfor; ?>
            </div>
            <div class="section-action"><a class="button button--outline" href="#contacts" data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal">Записаться на пробный урок</a></div>
        </div>
    </section>

    <section class="contact-section" id="contacts" aria-labelledby="contact-title">
        <div class="container">
            <div class="contact-panel">
                <div class="contact-panel__art" aria-hidden="true">
                    <img src="<?php echo $asset('icons/contact-doodle.svg'); ?>" alt="" width="250" height="180">
                </div>
                <div class="contact-panel__copy">
                    <h2 id="contact-title">ГОТОВЫ НАЧАТЬ?</h2>
                    <p>Оставьте заявку и получите<br>бесплатный пробный урок</p>
                </div>
                <form class="trial-form" id="trial-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" novalidate data-trial-form data-form-source="inline">
                    <input type="hidden" name="action" value="global_english_trial">
                    <input type="hidden" name="form_source" value="inline">
                    <?php wp_nonce_field('global_english_trial', 'global_english_nonce'); ?>
                    <div class="honeypot" aria-hidden="true"><label for="company">Компания</label><input id="company" name="company" type="text" tabindex="-1" autocomplete="off"></div>
                    <div class="form-field"><label class="sr-only" for="trial-name">Ваше имя</label><input id="trial-name" name="name" type="text" autocomplete="name" placeholder="Ваше имя" required aria-describedby="trial-name-error"><span class="field-error" id="trial-name-error"></span></div>
                    <div class="form-field"><label class="sr-only" for="trial-phone">Телефон</label><input id="trial-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (999) 999-99-99" required aria-describedby="trial-phone-error" data-phone-input><span class="field-error" id="trial-phone-error"></span></div>
                    <div class="form-field form-field--wide"><label class="sr-only" for="trial-language">Выберите язык</label><select id="trial-language" name="language" required aria-describedby="trial-language-error"><option value="">Выберите язык</option><option value="english">Английский язык</option><option value="chinese">Китайский язык</option><option value="ielts">Подготовка к IELTS / TOEFL</option></select><span class="field-error" id="trial-language-error"></span></div>
                    <button class="button button--primary form-submit" type="submit">Записаться на пробный урок</button>
                    <label class="consent"><input type="checkbox" name="consent" value="1" required aria-describedby="trial-consent-error"><span>Я согласен на <a href="<?php echo esc_url(global_english_privacy_url()); ?>">обработку персональных данных</a></span></label>
                    <span class="field-error" id="trial-consent-error"></span>
                    <div class="form-status" role="status" aria-live="polite" data-form-status<?php echo $inlineFormMessage ? ' data-status="' . esc_attr($inlineFormMessage[0]) . '"' : ''; ?>><?php echo $inlineFormMessage ? esc_html($inlineFormMessage[1]) : ''; ?></div>
                </form>
            </div>
        </div>
    </section>
</main>

<div class="enrollment-modal" id="enrollment-modal" data-enrollment-modal data-state="closed" aria-hidden="true" inert>
    <div class="enrollment-modal__backdrop" data-modal-backdrop></div>
    <section class="enrollment-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="enrollment-modal-title" aria-describedby="enrollment-modal-description" data-modal-dialog tabindex="-1">
        <button class="enrollment-modal__close" type="button" aria-label="Закрыть форму записи" data-modal-close>
            <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M5 5l14 14M19 5 5 19"/></svg>
        </button>
        <div class="enrollment-modal__header">
            <p class="eyebrow">БЕСПЛАТНЫЙ ПРОБНЫЙ УРОК</p>
            <h2 id="enrollment-modal-title">Записаться на пробный урок</h2>
            <p id="enrollment-modal-description">Оставьте контакты — администратор уточнит ваш уровень и подберёт удобное время.</p>
        </div>
        <form class="trial-form enrollment-modal__form" id="modal-trial-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" novalidate data-trial-form data-form-source="modal">
            <input type="hidden" name="action" value="global_english_trial">
            <input type="hidden" name="form_source" value="modal">
            <?php wp_nonce_field('global_english_trial', 'global_english_nonce'); ?>
            <div class="honeypot" aria-hidden="true"><label for="modal-company">Компания</label><input id="modal-company" name="company" type="text" tabindex="-1" autocomplete="off"></div>
            <div class="form-field"><label class="sr-only" for="modal-trial-name">Ваше имя</label><input id="modal-trial-name" name="name" type="text" autocomplete="name" placeholder="Ваше имя" required aria-describedby="modal-trial-name-error"><span class="field-error" id="modal-trial-name-error"></span></div>
            <div class="form-field"><label class="sr-only" for="modal-trial-phone">Телефон</label><input id="modal-trial-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (999) 999-99-99" required aria-describedby="modal-trial-phone-error" data-phone-input><span class="field-error" id="modal-trial-phone-error"></span></div>
            <div class="form-field form-field--wide"><label class="sr-only" for="modal-trial-language">Выберите язык</label><select id="modal-trial-language" name="language" required aria-describedby="modal-trial-language-error"><option value="">Выберите язык</option><option value="english">Английский язык</option><option value="chinese">Китайский язык</option><option value="ielts">Подготовка к IELTS / TOEFL</option></select><span class="field-error" id="modal-trial-language-error"></span></div>
            <button class="button button--primary form-submit" type="submit">Записаться на пробный урок</button>
            <label class="consent"><input type="checkbox" name="consent" value="1" required aria-describedby="modal-trial-consent-error"><span>Я согласен на <a href="<?php echo esc_url(global_english_privacy_url()); ?>">обработку персональных данных</a></span></label>
            <span class="field-error" id="modal-trial-consent-error"></span>
            <div class="form-status" role="status" aria-live="polite" data-form-status<?php echo $modalFormMessage ? ' data-status="' . esc_attr($modalFormMessage[0]) . '"' : ''; ?>><?php echo $modalFormMessage ? esc_html($modalFormMessage[1]) : ''; ?></div>
        </form>
    </section>
</div>

<?php get_footer(); ?>
