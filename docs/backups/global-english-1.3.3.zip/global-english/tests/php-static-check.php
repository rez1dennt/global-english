<?php

declare(strict_types=1);

$themeRoot = dirname(__DIR__);
$failures = [];

function check_contract(bool $condition, string $message): void
{
    global $failures;
    if (!$condition) {
        $failures[] = $message;
    }
}

$stylePath = $themeRoot . DIRECTORY_SEPARATOR . 'style.css';
$functionsPath = $themeRoot . DIRECTORY_SEPARATOR . 'functions.php';
$headerPath = $themeRoot . DIRECTORY_SEPARATOR . 'header.php';
$frontPagePath = $themeRoot . DIRECTORY_SEPARATOR . 'front-page.php';
$footerPath = $themeRoot . DIRECTORY_SEPARATOR . 'footer.php';
$indexPath = $themeRoot . DIRECTORY_SEPARATOR . 'index.php';
$privacyPath = $themeRoot . DIRECTORY_SEPARATOR . 'page-privacy-policy.php';
$mainCssPath = $themeRoot . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'css' . DIRECTORY_SEPARATOR . 'main.css';

check_contract(is_file($stylePath), 'Missing style.css');
check_contract(is_file($functionsPath), 'Missing functions.php');
check_contract(is_file($headerPath), 'Missing header.php');
check_contract(is_file($frontPagePath), 'Missing front-page.php');
check_contract(is_file($footerPath), 'Missing footer.php');
check_contract(is_file($indexPath), 'Missing index.php');
check_contract(is_file($privacyPath), 'Missing page-privacy-policy.php');

$style = is_file($stylePath) ? (string) file_get_contents($stylePath) : '';
$functions = is_file($functionsPath) ? (string) file_get_contents($functionsPath) : '';
$header = is_file($headerPath) ? (string) file_get_contents($headerPath) : '';
$frontPage = is_file($frontPagePath) ? (string) file_get_contents($frontPagePath) : '';
$footer = is_file($footerPath) ? (string) file_get_contents($footerPath) : '';
$mainCss = is_file($mainCssPath) ? (string) file_get_contents($mainCssPath) : '';

check_contract(str_contains($style, 'Theme Name: Global English'), 'Theme header is missing its name');
check_contract(str_contains($functions, "add_action('after_setup_theme'"), 'after_setup_theme hook is missing');
check_contract(str_contains($functions, "add_action('wp_enqueue_scripts'"), 'wp_enqueue_scripts hook is missing');
check_contract(substr_count($frontPage, '<h1') === 1, 'front-page.php must contain exactly one h1');
check_contract(str_contains($frontPage, 'get_header()'), 'front-page.php must call get_header()');
check_contract(str_contains($frontPage, 'get_footer()'), 'front-page.php must call get_footer()');
check_contract(str_contains($header, 'wp_head()'), 'header.php must call wp_head()');
check_contract(str_contains($header, 'wp_body_open()'), 'header.php must call wp_body_open()');
check_contract(str_contains($footer, 'wp_footer()'), 'footer.php must call wp_footer()');
check_contract(substr_count($header . $footer, 'brand__mark') === 0, 'Header and footer brand must be text-only');
check_contract(str_contains($frontPage, 'course-card__content'), 'Course cards must contain the horizontal content wrapper');
check_contract(str_contains($mainCss, '.course-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr))'), 'Desktop course grid must use two columns');
check_contract(str_contains($mainCss, '.course-card { display: flex; min-height: 0; flex-direction: row'), 'Course cards must use compact horizontal layout');
check_contract(str_contains($mainCss, '.course-grid { grid-template-columns: 1fr; }'), 'Mobile course grid must use one column');

foreach ([
    '.form-field:has(> select)::after',
    'pointer-events: none',
    'transition: transform var(--motion-base) var(--ease-out)',
    '.form-field:has(> select:open)::after',
    'transform: rotate(180deg)',
] as $selectRotationContract) {
    check_contract(str_contains($mainCss, $selectRotationContract), 'Missing select rotation contract: ' . $selectRotationContract);
}

foreach (['about', 'courses', 'method', 'benefits', 'teachers', 'reviews', 'contacts'] as $anchorId) {
    $template = $header . $frontPage . $footer;
    check_contract(substr_count($template, 'id="' . $anchorId . '"') === 1, 'Anchor #' . $anchorId . ' must occur exactly once');
}

foreach ([
    "add_action('admin_post_nopriv_global_english_trial'",
    "add_action('admin_post_global_english_trial'",
    "wp_verify_nonce(",
    "sanitize_text_field(",
    "set_transient(",
    "wp_mail(",
] as $requiredFormContract) {
    check_contract(str_contains($functions, $requiredFormContract), 'Missing form contract: ' . $requiredFormContract);
}

foreach ([
    "add_action('after_switch_theme'",
    'global_english_privacy_url',
    'wp_insert_post(',
    'wp_page_for_privacy_policy',
    "'global-english-cookie-consent'",
    "'global-english-scroll-lock'",
] as $requiredPrivacyContract) {
    check_contract(str_contains($functions, $requiredPrivacyContract), 'Missing privacy contract: ' . $requiredPrivacyContract);
}

check_contract(str_contains($frontPage, 'global_english_privacy_url()'), 'Form consent must link to the privacy policy');
check_contract(str_contains($footer, 'data-cookie-banner'), 'Cookie banner markup is missing');
check_contract(str_contains($footer, 'data-cookie-settings'), 'Cookie settings control is missing');

$modalPath = $themeRoot . '/assets/js/modal.js';
check_contract(is_file($modalPath), 'Missing modal.js');
check_contract(str_contains($functions, "'global-english-modal'"), 'Modal script must be enqueued');
check_contract(str_contains($functions, 'form_source'), 'Server redirect must preserve the form source');
check_contract(str_contains($frontPage, 'data-enrollment-modal'), 'Enrollment modal markup is missing');
check_contract(str_contains($frontPage, 'role="dialog"'), 'Enrollment modal dialog role is missing');
check_contract(str_contains($frontPage, 'aria-modal="true"'), 'Enrollment modal aria-modal is missing');
check_contract(substr_count($header . $frontPage, 'data-enrollment-modal-trigger') === 6, 'Exactly six enrollment CTA triggers are required');
$expectedModalTriggerLabels = [
    'Записаться на пробный урок',
    'Попробовать бесплатно',
    'Подобрать курс',
    'Попробовать методику',
    'Начать обучение',
    'Записаться на пробный урок',
];
$ctaTemplate = preg_replace('/<\?php.*?\?>/su', '', $header . $frontPage) ?? '';
preg_match_all('/<a[^>]*data-enrollment-modal-trigger[^>]*>(.*?)<\/a>/su', $ctaTemplate, $ctaMatches);
$actualModalTriggerLabels = array_map(
    static fn(string $label): string => trim(strip_tags($label)),
    $ctaMatches[1] ?? []
);
check_contract($actualModalTriggerLabels === $expectedModalTriggerLabels, 'Enrollment CTA labels must match the approved contextual copy');
check_contract(substr_count($frontPage, '>Записаться на пробный урок</button>') === 2, 'Both form submit buttons must use the trial-lesson CTA');
foreach (['Все курсы', 'Подробнее о методике', 'Смотреть больше фото'] as $legacyLabel) {
    check_contract(!str_contains($header . $frontPage, '>' . $legacyLabel . '</a>'), 'Legacy CTA label is forbidden: ' . $legacyLabel);
}
check_contract(str_contains($frontPage, 'data-form-source="inline"'), 'Inline form source is missing');
check_contract(str_contains($frontPage, 'data-form-source="modal"'), 'Modal form source is missing');
check_contract(str_contains($frontPage, 'name="form_source" value="inline"'), 'Inline POST source is missing');
check_contract(str_contains($frontPage, 'name="form_source" value="modal"'), 'Modal POST source is missing');

preg_match_all('/\sid="([^"]+)"/', $frontPage, $idMatches);
$literalIds = $idMatches[1] ?? [];
check_contract(count($literalIds) === count(array_unique($literalIds)), 'front-page.php contains duplicate literal IDs');

$allTemplates = $header . $frontPage . $footer;
preg_match_all("~/assets/(?:images|icons)/[^'\"\)]+~", $allTemplates, $assetMatches);
foreach (array_unique($assetMatches[0] ?? []) as $assetReference) {
    check_contract(is_file($themeRoot . str_replace('/', DIRECTORY_SEPARATOR, $assetReference)), 'Missing referenced asset: ' . $assetReference);
}

$requiredImages = [
    'hero-student.webp', 'hero-landmarks.webp', 'method-online.webp', 'opportunity-students.webp',
    'opportunity-london.webp', 'opportunity-china.webp', 'opportunity-study.webp',
    'teacher-anna.webp', 'teacher-li.webp', 'teacher-michael.webp', 'teacher-zhang.webp',
    'class-01.webp', 'class-02.webp', 'class-03.webp', 'class-04.webp',
];
foreach ($requiredImages as $imageName) {
    check_contract(is_file($themeRoot . '/assets/images/' . $imageName), 'Missing image: ' . $imageName);
}

$requiredIcons = [
    'phone.svg', 'big-ben.svg', 'crown.svg', 'graduation-cap.svg', 'pagoda.svg',
    'users.svg', 'book-open.svg', 'trophy.svg', 'clock.svg', 'messages.svg',
    'book-check.svg', 'route.svg', 'flask.svg', 'plane.svg', 'briefcase.svg',
    'university.svg', 'passport.svg', 'medal.svg', 'students.svg', 'teacher.svg',
    'certificate.svg', 'chevron-left.svg', 'chevron-right.svg', 'chevron-down.svg', 'star.svg',
    'contact-doodle.svg', 'vk.svg', 'telegram.svg', 'instagram.svg', 'mail.svg', 'map-pin.svg', 'favicon.svg',
];
foreach ($requiredIcons as $iconName) {
    check_contract(is_file($themeRoot . '/assets/icons/' . $iconName), 'Missing icon: ' . $iconName);
}

check_contract(is_file($themeRoot . '/screenshot.png'), 'Missing WordPress screenshot.png');

if ($failures !== []) {
    fwrite(STDERR, "Theme foundation: FAIL\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

fwrite(STDOUT, "Theme foundation: PASS\n");
