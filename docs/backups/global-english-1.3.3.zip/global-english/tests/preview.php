<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli-server') {
    http_response_code(404);
    exit;
}

define('ABSPATH', dirname(__DIR__) . DIRECTORY_SEPARATOR);

function language_attributes(): void { echo 'lang="ru"'; }
function bloginfo(string $name): void { echo $name === 'charset' ? 'UTF-8' : 'Global English'; }
function body_class(): void { echo str_contains($_SERVER['REQUEST_URI'] ?? '', 'privacy-policy') ? 'class="page page-template-page-privacy-policy"' : 'class="home page-template-front-page"'; }
function wp_body_open(): void {}
function esc_url(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function esc_attr(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function esc_html(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function wp_unslash(string $value): string { return stripslashes($value); }
function sanitize_key(string $value): string { return preg_replace('/[^a-z0-9_\-]/', '', strtolower($value)) ?? ''; }
function get_theme_file_uri(string $path = ''): string { return '/global-english' . $path; }
function admin_url(string $path = ''): string { return '#' . $path; }
function home_url(string $path = ''): string { return $path === '' ? '/' : $path; }
function global_english_privacy_url(): string { return '/privacy-policy/'; }
function global_english_section_url(string $section): string { return str_contains($_SERVER['REQUEST_URI'] ?? '', 'privacy-policy') ? '/#' . $section : '#' . $section; }
function is_front_page(): bool { return !str_contains($_SERVER['REQUEST_URI'] ?? '', 'privacy-policy'); }
function wp_date(string $format): string { return date($format); }
function wp_nonce_field(string $action, string $name): void { echo '<input type="hidden" name="' . esc_attr($name) . '" value="preview">'; }
function wp_head(): void {
    echo '<title>Global English</title><link rel="stylesheet" href="/global-english/assets/css/main.css">';
    if (isset($_GET['static'])) {
        echo '<style>.cookie-banner{display:none!important}</style>';
    }
}
function wp_footer(): void {
    if (!isset($_GET['static'])) {
        echo '<script src="/global-english/assets/js/phone-mask.js"></script><script src="/global-english/assets/js/cookie-consent.js"></script><script src="/global-english/assets/js/scroll-lock.js"></script><script src="/global-english/assets/js/modal.js"></script><script src="/global-english/assets/js/main.js"></script>';
    }
    if (isset($_GET['qa'])) {
        echo '<script>window.setTimeout(function(){var images=Array.from(document.images);var result={width:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,overflow:document.documentElement.scrollWidth>document.documentElement.clientWidth+1,images:images.length,brokenImages:images.filter(function(image){return !image.complete||image.naturalWidth===0;}).length,fontLoaded:document.fonts.check("16px Manrope"),cookieState:(document.querySelector("[data-cookie-banner]")||{}).dataset?.state||"missing",menuState:(document.querySelector("[data-menu-panel]")||{}).dataset?.state||"missing"};document.body.setAttribute("data-qa-result",encodeURIComponent(JSON.stringify(result)));},1200);</script>';
    }
}
function get_header(): void { require dirname(__DIR__) . '/header.php'; }
function get_footer(): void { require dirname(__DIR__) . '/footer.php'; }

if (str_contains($_SERVER['REQUEST_URI'] ?? '', 'privacy-policy')) {
    require dirname(__DIR__) . '/page-privacy-policy.php';
} else {
    require dirname(__DIR__) . '/front-page.php';
}
