import assert from 'node:assert/strict';

const debugPort = process.env.CHROME_DEBUG_PORT || '9223';
const pages = await fetch(`http://127.0.0.1:${debugPort}/json`).then((response) => response.json());
const pageTarget = pages.find((page) => page.type === 'page' && page.webSocketDebuggerUrl);
assert.ok(pageTarget?.webSocketDebuggerUrl, 'Chrome DevTools page is unavailable');

const socket = new WebSocket(pageTarget.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
});

let commandId = 0;
const pending = new Map();
const eventWaiters = new Map();
let browserErrors = [];

socket.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
        const { resolve, reject, timer } = pending.get(message.id);
        pending.delete(message.id);
        clearTimeout(timer);
        if (message.error) reject(new Error(message.error.message));
        else resolve(message.result);
        return;
    }
    if (message.method === 'Runtime.exceptionThrown') {
        browserErrors.push(message.params.exceptionDetails.text || 'Runtime exception');
    }
    if (message.method === 'Log.entryAdded' && message.params.entry.level === 'error') {
        browserErrors.push(message.params.entry.text);
    }
    const waiters = eventWaiters.get(message.method) || [];
    eventWaiters.delete(message.method);
    waiters.forEach((resolve) => resolve(message.params));
});

function send(method, params = {}) {
    const id = ++commandId;
    socket.send(JSON.stringify({ id, method, params }));
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            pending.delete(id);
            reject(new Error(`CDP command timed out: ${method}`));
        }, 15000);
        pending.set(id, { resolve, reject, timer });
    });
}

function waitForEvent(method) {
    return new Promise((resolve, reject) => {
        const waiters = eventWaiters.get(method) || [];
        const timer = setTimeout(() => reject(new Error(`CDP event timed out: ${method}`)), 15000);
        waiters.push((params) => {
            clearTimeout(timer);
            resolve(params);
        });
        eventWaiters.set(method, waiters);
    });
}

const delay = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

async function waitUntilReady(expectedUrlPart) {
    for (let attempt = 0; attempt < 150; attempt += 1) {
        const evaluation = await send('Runtime.evaluate', {
            returnByValue: true,
            expression: '({state:document.readyState,href:location.href})',
        });
        if (evaluation.result.value.state === 'complete' && evaluation.result.value.href.includes(expectedUrlPart)) {
            return;
        }
        await delay(100);
    }
    throw new Error('Page did not reach readyState=complete');
}

await Promise.all([
    send('Page.enable'),
    send('Runtime.enable'),
    send('Log.enable'),
]);
await send('DOM.enable');
await send('CSS.enable');

for (const width of [1440, 1024, 768, 360, 320]) {
    browserErrors = [];
    await send('Emulation.setDeviceMetricsOverride', {
        width,
        height: 900,
        deviceScaleFactor: 1,
        mobile: width <= 768,
        screenWidth: width,
        screenHeight: 900,
    });
    await send('Page.navigate', { url: `http://127.0.0.1:8765/global-english/tests/preview.php?qa=${width}` });
    await waitUntilReady('preview.php?qa=');
    await send('Runtime.evaluate', { expression: 'window.scrollTo(0, document.documentElement.scrollHeight)' });
    await delay(700);
    await send('Runtime.evaluate', { expression: 'const track=document.querySelector("[data-slider-track]");if(track){track.scrollLeft=track.scrollWidth;}' });
    await delay(500);
    await send('Runtime.evaluate', { expression: 'window.scrollTo(0, 0)' });
    await delay(1100);

    const evaluation = await send('Runtime.evaluate', {
        returnByValue: true,
        expression: `(() => {
            const root = document.documentElement;
            const images = Array.from(document.images);
            const panel = document.querySelector('[data-menu-panel]');
            const cookie = document.querySelector('[data-cookie-banner]');
            return {
                width: root.clientWidth,
                viewportWidth: window.innerWidth,
                scrollWidth: root.scrollWidth,
                overflow: root.scrollWidth > root.clientWidth + 1,
                imageCount: images.length,
                brokenImages: images.filter((image) => !image.complete || image.naturalWidth === 0).length,
                brokenSources: images.filter((image) => !image.complete || image.naturalWidth === 0).map((image) => image.currentSrc || image.src),
                fontLoaded: document.fonts.check('16px Manrope'),
                menuState: panel ? panel.dataset.state : 'missing',
                menuHidden: ${width} > 960 || (panel && panel.getAttribute('aria-hidden') === 'true'),
                cookieState: cookie ? cookie.dataset.state : 'missing',
                headerTop: document.querySelector('.site-header')?.getBoundingClientRect().top,
                headerLeft: document.querySelector('.site-header')?.getBoundingClientRect().left,
                headerRight: document.querySelector('.site-header')?.getBoundingClientRect().right,
                courseColumns: getComputedStyle(document.querySelector('.course-grid')).gridTemplateColumns.split(' ').length,
                courseDirection: getComputedStyle(document.querySelector('.course-card')).flexDirection,
                courseTextAlign: getComputedStyle(document.querySelector('.course-card')).textAlign,
            };
        })()`,
    });
    const result = evaluation.result.value;
    assert.equal(result.viewportWidth, width, `${width}px viewport was not applied`);
    assert.equal(result.overflow, false, `${width}px layout has horizontal overflow (${result.scrollWidth}px)`);
    assert.equal(result.brokenImages, 0, `${width}px layout has broken images: ${result.brokenSources.join(', ')}`);
    assert.equal(result.fontLoaded, true, `${width}px Manrope did not load`);
    assert.equal(result.menuHidden, true, `${width}px mobile menu initial state is exposed`);
    assert.equal(result.headerTop, 0, `${width}px fixed header moved vertically`);
    assert.equal(result.headerLeft, 0, `${width}px fixed header moved from the left edge`);
    assert.equal(result.headerRight, result.width, `${width}px fixed header is not full width`);
    assert.equal(result.courseColumns, width <= 704 ? 1 : 2, `${width}px course grid has incorrect column count`);
    assert.equal(result.courseDirection, 'row', `${width}px course card is not horizontal`);
    assert.equal(result.courseTextAlign, 'start', `${width}px course card text is not start-aligned`);
    assert.deepEqual(browserErrors, [], `${width}px browser console contains errors`);
    console.log(`${width}px: PASS`, JSON.stringify(result));
}

await send('Emulation.setDeviceMetricsOverride', {
    width: 900,
    height: 900,
    deviceScaleFactor: 1,
    mobile: false,
    screenWidth: 900,
    screenHeight: 900,
});
await send('Page.navigate', { url: 'http://127.0.0.1:8765/global-english/tests/preview.php?interaction=1' });
await waitUntilReady('preview.php?interaction=1');
await delay(1200);
await send('Runtime.evaluate', { expression: 'window.scrollTo(0, 700)' });
await delay(100);
let interaction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => {
        const toggle = document.querySelector('[data-menu-toggle]');
        const before = window.scrollY;
        const header = document.querySelector('[data-site-header]');
        const brand = document.querySelector('.brand');
        const hero = document.querySelector('.hero__copy');
        const beforeGeometry = {
            brandLeft: brand.getBoundingClientRect().left,
            toggleLeft: toggle.getBoundingClientRect().left,
            heroLeft: hero.getBoundingClientRect().left,
        };
        const expectedGap = window.innerWidth - document.documentElement.clientWidth;
        toggle.click();
        const afterGeometry = {
            brandLeft: brand.getBoundingClientRect().left,
            toggleLeft: toggle.getBoundingClientRect().left,
            heroLeft: hero.getBoundingClientRect().left,
        };
        return {
            before,
            expanded: toggle.getAttribute('aria-expanded'),
            state: document.querySelector('[data-menu-panel]').dataset.state,
            expectedGap,
            bodyPadding: parseFloat(getComputedStyle(document.body).paddingRight) || 0,
            headerPadding: parseFloat(getComputedStyle(header).paddingRight) || 0,
            beforeGeometry,
            afterGeometry,
        };
    })()`,
});
assert.equal(interaction.result.value.expanded, 'true', 'Burger menu did not set aria-expanded');
assert.equal(interaction.result.value.state, 'open', 'Burger menu did not open');
assert.ok(interaction.result.value.expectedGap > 0, 'Burger regression viewport has no classic scrollbar gap');
assert.ok(interaction.result.value.bodyPadding >= interaction.result.value.expectedGap, 'Body did not receive scrollbar compensation');
assert.ok(interaction.result.value.headerPadding >= interaction.result.value.expectedGap, 'Fixed header did not receive scrollbar compensation');
for (const key of ['brandLeft', 'toggleLeft', 'heroLeft']) {
    assert.ok(Math.abs(interaction.result.value.beforeGeometry[key] - interaction.result.value.afterGeometry[key]) <= 1, `${key} shifted when burger opened`);
}
const scrollBeforeMenu = interaction.result.value.before;
await delay(380);
interaction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => {
        const header = document.querySelector('.site-header').getBoundingClientRect();
        document.querySelector('[data-menu-toggle]').click();
        return { headerTop: header.top, headerLeft: header.left, closingState: document.querySelector('[data-menu-panel]').dataset.state };
    })()`,
});
assert.equal(interaction.result.value.headerTop, 0, 'Header moved while burger was open');
assert.equal(interaction.result.value.headerLeft, 0, 'Header shifted while burger was open');
assert.equal(interaction.result.value.closingState, 'closing', 'Burger close animation did not start');
await delay(420);
interaction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => ({
        after: window.scrollY,
        expanded: document.querySelector('[data-menu-toggle]').getAttribute('aria-expanded'),
        state: document.querySelector('[data-menu-panel]').dataset.state,
    }))()`,
});
assert.ok(Math.abs(interaction.result.value.after - scrollBeforeMenu) <= 1, 'Burger menu did not restore scroll position');
assert.equal(interaction.result.value.expanded, 'false', 'Burger menu did not reset aria-expanded');
assert.equal(interaction.result.value.state, 'closed', 'Burger menu did not finish closing');

await send('Runtime.evaluate', { expression: `document.querySelector('[data-menu-toggle]').click();document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));` });
await delay(420);
interaction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        expanded: document.querySelector('[data-menu-toggle]').getAttribute('aria-expanded'),
        state: document.querySelector('[data-menu-panel]').dataset.state,
        focusReturned: document.activeElement === document.querySelector('[data-menu-toggle]'),
    })`,
});
assert.deepEqual(interaction.result.value, { expanded: 'false', state: 'closed', focusReturned: true }, 'Escape did not close burger and restore focus');

await send('Runtime.evaluate', { expression: `document.querySelector('[data-trial-form]').dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}))` });
await delay(50);
interaction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        invalidFields: document.querySelectorAll('[data-trial-form] [aria-invalid="true"]').length,
        status: document.querySelector('[data-form-status]').textContent.trim(),
        privacyHref: document.querySelector('.consent a').getAttribute('href'),
    })`,
});
assert.equal(interaction.result.value.invalidFields, 4, 'Empty form validation did not mark all required fields');
assert.equal(interaction.result.value.status, 'Исправьте отмеченные поля.', 'Form validation status is missing');
assert.equal(interaction.result.value.privacyHref, '/privacy-policy/', 'Form privacy link is incorrect');

await send('Runtime.evaluate', { expression: `document.querySelector('.hero__actions a[href="#courses"]').click()` });
await delay(2200);
interaction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => { const top=document.querySelector('#courses').getBoundingClientRect().top; const header=document.querySelector('.site-header').getBoundingClientRect().height; return {top,header}; })()`,
});
assert.ok(interaction.result.value.top >= interaction.result.value.header - 1 && interaction.result.value.top <= interaction.result.value.header + 40, `Anchor offset does not clear the fixed header: top=${interaction.result.value.top}, header=${interaction.result.value.header}`);
console.log('burger and form interactions: PASS');

const modalTriggerEvaluation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => {
        const triggers = Array.from(document.querySelectorAll('[data-enrollment-modal-trigger]'));
        return {
            count: triggers.length,
            labels: triggers.map((trigger) => trigger.textContent.replace(/\s+/g, ' ').trim()),
        };
    })()`,
});
assert.equal(modalTriggerEvaluation.result.value.count, 6, 'Enrollment modal must have six CTA triggers');
assert.deepEqual(modalTriggerEvaluation.result.value.labels, [
    'Записаться на пробный урок',
    'Попробовать бесплатно',
    'Подобрать курс',
    'Попробовать методику',
    'Начать обучение',
    'Записаться на пробный урок',
], 'Enrollment CTA labels do not match the approved contextual copy');

const selectStyleEvaluation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `Array.from(document.querySelectorAll('.form-field select')).map((select) => {
        const style = getComputedStyle(select);
        const arrow = getComputedStyle(select.parentElement, '::after');
        return {
            appearance: style.appearance,
            paddingRight: parseFloat(style.paddingRight),
            backgroundImage: style.backgroundImage,
            arrowBackgroundImage: arrow.backgroundImage,
            arrowInsetRight: parseFloat(arrow.right),
            arrowWidth: parseFloat(arrow.width),
            arrowHeight: parseFloat(arrow.height),
        };
    })`,
});
const selectStyles = selectStyleEvaluation.result.value;
assert.equal(selectStyles.length, 2, 'Inline and modal language selects must both be present');
for (const [selectIndex, selectStyle] of selectStyles.entries()) {
    assert.equal(selectStyle.appearance, 'none', `Select ${selectIndex + 1} must hide the cramped system arrow`);
    assert.equal(selectStyle.paddingRight, 40, `Select ${selectIndex + 1} must reserve 40px for its arrow`);
    assert.equal(selectStyle.backgroundImage, 'none', `Select ${selectIndex + 1} must not paint a non-rotatable background arrow`);
    assert.match(selectStyle.arrowBackgroundImage, /chevron-down\.svg/, `Select ${selectIndex + 1} wrapper must use the local SVG arrow`);
    assert.equal(selectStyle.arrowInsetRight, 16, `Select ${selectIndex + 1} arrow must be inset 16px from the right edge`);
    assert.equal(selectStyle.arrowWidth, 16, `Select ${selectIndex + 1} arrow width must be 16px`);
    assert.equal(selectStyle.arrowHeight, 16, `Select ${selectIndex + 1} arrow height must be 16px`);
}

const selectOpenSupport = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `CSS.supports('selector(select:open)')`,
});
assert.equal(selectOpenSupport.result.value, true, 'Current Chrome must support the native select :open state');

const documentNode = await send('DOM.getDocument');
const inlineSelectNode = await send('DOM.querySelector', {
    nodeId: documentNode.root.nodeId,
    selector: '[data-form-source="inline"] select',
});
assert.ok(inlineSelectNode.nodeId, 'Inline select DOM node is unavailable');
await send('CSS.forcePseudoState', {
    nodeId: inlineSelectNode.nodeId,
    forcedPseudoClasses: ['open'],
});
await delay(380);
let selectRotation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => {
        const select = document.querySelector('[data-form-source="inline"] select');
        const arrow = getComputedStyle(select.parentElement, '::after');
        return {
            transform: arrow.transform,
            transitionDuration: parseFloat(arrow.transitionDuration) || 0,
        };
    })()`,
});
assert.notEqual(selectRotation.result.value.transform, 'none', 'Select arrow has no open-state transform');
assert.notEqual(selectRotation.result.value.transform, 'matrix(1, 0, 0, 1, 0, 0)', 'Select arrow did not rotate while the picker was open');
assert.ok(selectRotation.result.value.transitionDuration > 0, 'Select arrow rotation is not animated');

await send('CSS.forcePseudoState', {
    nodeId: inlineSelectNode.nodeId,
    forcedPseudoClasses: [],
});
await delay(380);
selectRotation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => {
        const select = document.querySelector('[data-form-source="inline"] select');
        return {
            transform: getComputedStyle(select.parentElement, '::after').transform,
        };
    })()`,
});
assert.deepEqual(selectRotation.result.value, {
    transform: 'matrix(1, 0, 0, 1, 0, 0)',
}, 'Select arrow did not return to its closed position');

for (let triggerIndex = 0; triggerIndex < 6; triggerIndex += 1) {
    await send('Runtime.evaluate', {
        expression: `document.querySelectorAll('[data-enrollment-modal-trigger]')[${triggerIndex}].click()`,
    });
    await delay(80);
    let modalState = await send('Runtime.evaluate', {
        returnByValue: true,
        expression: `({
            state: document.querySelector('[data-enrollment-modal]').dataset.state,
            hidden: document.querySelector('[data-enrollment-modal]').getAttribute('aria-hidden'),
            focusId: document.activeElement.id,
            mainInert: document.querySelector('main').inert,
        })`,
    });
    assert.deepEqual(modalState.result.value, {
        state: 'open',
        hidden: 'false',
        focusId: 'modal-trial-name',
        mainInert: true,
    }, `CTA ${triggerIndex + 1} did not open the modal correctly`);
    await send('Runtime.evaluate', { expression: `document.querySelector('[data-modal-close]').click()` });
    await delay(420);
    modalState = await send('Runtime.evaluate', {
        returnByValue: true,
        expression: `({
            state: document.querySelector('[data-enrollment-modal]').dataset.state,
            hidden: document.querySelector('[data-enrollment-modal]').getAttribute('aria-hidden'),
            focusReturned: document.activeElement === document.querySelectorAll('[data-enrollment-modal-trigger]')[${triggerIndex}],
            mainInert: document.querySelector('main').inert,
        })`,
    });
    assert.deepEqual(modalState.result.value, {
        state: 'closed',
        hidden: 'true',
        focusReturned: true,
        mainInert: false,
    }, `CTA ${triggerIndex + 1} modal did not close cleanly`);
}

let modalScrollBefore = await send('Runtime.evaluate', { returnByValue: true, expression: 'window.scrollY' });
await send('Runtime.evaluate', { expression: `document.querySelectorAll('[data-enrollment-modal-trigger]')[1].click()` });
await delay(80);
await send('Runtime.evaluate', { expression: `document.querySelector('[data-modal-dialog]').querySelectorAll('a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),[tabindex]:not([tabindex="-1"])').item(document.querySelector('[data-modal-dialog]').querySelectorAll('a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),[tabindex]:not([tabindex="-1"])').length-1).focus();document.dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',bubbles:true,cancelable:true}));` });
let modalInteraction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({ focusTrapped: document.activeElement === document.querySelector('[data-modal-close]') })`,
});
assert.equal(modalInteraction.result.value.focusTrapped, true, 'Modal Tab cycle did not wrap to the first control');

await send('Runtime.evaluate', { expression: `document.querySelector('[data-form-source="modal"]').dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}))` });
await delay(50);
modalInteraction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        invalidFields: document.querySelectorAll('[data-form-source="modal"] [aria-invalid="true"]').length,
        status: document.querySelector('[data-form-source="modal"] [data-form-status]').textContent.trim(),
    })`,
});
assert.deepEqual(modalInteraction.result.value, { invalidFields: 4, status: 'Исправьте отмеченные поля.' }, 'Modal form validation failed');

await send('Runtime.evaluate', { expression: `document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}))` });
modalInteraction = await send('Runtime.evaluate', { returnByValue: true, expression: `document.querySelector('[data-enrollment-modal]').dataset.state` });
assert.equal(modalInteraction.result.value, 'closing', 'Escape did not start the modal close transition');
await delay(420);
modalInteraction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        state: document.querySelector('[data-enrollment-modal]').dataset.state,
        scrollY: window.scrollY,
        focusReturned: document.activeElement === document.querySelectorAll('[data-enrollment-modal-trigger]')[1],
    })`,
});
assert.equal(modalInteraction.result.value.state, 'closed', 'Escape did not finish closing the modal');
assert.ok(Math.abs(modalInteraction.result.value.scrollY - modalScrollBefore.result.value) <= 1, 'Modal did not restore scroll position');
assert.equal(modalInteraction.result.value.focusReturned, true, 'Modal did not return focus after Escape');

await send('Runtime.evaluate', { expression: `document.querySelectorAll('[data-enrollment-modal-trigger]')[2].click()` });
await delay(80);
await send('Runtime.evaluate', { expression: `document.querySelector('[data-modal-backdrop]').click()` });
await delay(420);
modalInteraction = await send('Runtime.evaluate', { returnByValue: true, expression: `document.querySelector('[data-enrollment-modal]').dataset.state` });
assert.equal(modalInteraction.result.value, 'closed', 'Backdrop did not close the modal');
console.log('enrollment modal interactions: PASS');

await send('Page.navigate', { url: 'http://127.0.0.1:8765/global-english/tests/preview.php?form_status=success&form_source=modal' });
await waitUntilReady('form_source=modal');
await delay(120);
modalInteraction = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        state: document.querySelector('[data-enrollment-modal]').dataset.state,
        modalStatus: document.querySelector('[data-form-source="modal"] [data-form-status]').textContent.trim(),
        inlineStatus: document.querySelector('[data-form-source="inline"] [data-form-status]').textContent.trim(),
    })`,
});
assert.deepEqual(modalInteraction.result.value, {
    state: 'open',
    modalStatus: 'Заявка отправлена. Мы свяжемся с вами в ближайшее время.',
    inlineStatus: '',
}, 'Modal server status did not reopen in the correct form');
await send('Runtime.evaluate', { expression: `document.querySelector('[data-modal-close]').click()` });
await delay(420);
console.log('modal server response: PASS');
assert.deepEqual(browserErrors, [], 'Enrollment modal browser console contains errors');

browserErrors = [];
await send('Storage.clearDataForOrigin', { origin: 'http://127.0.0.1:8765', storageTypes: 'local_storage' });
await send('Emulation.setDeviceMetricsOverride', {
    width: 360,
    height: 900,
    deviceScaleFactor: 1,
    mobile: true,
    screenWidth: 360,
    screenHeight: 900,
});
await send('Page.navigate', { url: 'http://127.0.0.1:8765/global-english/tests/preview.php?privacy-policy=1&qa=privacy' });
await waitUntilReady('privacy-policy=1');
await delay(1400);
const privacyEvaluation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => ({
        overflow: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
        width: document.documentElement.clientWidth,
        scrollWidth: document.documentElement.scrollWidth,
        offenders: Array.from(document.querySelectorAll('body *')).filter((element) => { const rect=element.getBoundingClientRect(); return rect.right>document.documentElement.clientWidth+1||rect.left<-1; }).slice(0,8).map((element) => element.tagName+'.'+element.className),
        heading: document.querySelector('h1')?.textContent.trim() || '',
        sections: document.querySelectorAll('.legal-content h2').length,
        brokenImages: Array.from(document.images).filter((image) => !image.complete || image.naturalWidth === 0).length,
    }))()`,
});
const privacy = privacyEvaluation.result.value;
assert.equal(privacy.overflow, false, `Privacy page has horizontal overflow at 360px: ${privacy.scrollWidth}/${privacy.width}; ${privacy.offenders.join(', ')}`);
assert.equal(privacy.heading, 'Политика конфиденциальности', 'Privacy page heading is missing');
assert.equal(privacy.sections, 8, 'Privacy page sections are incomplete');
assert.equal(privacy.brokenImages, 0, 'Privacy page has broken images');
assert.deepEqual(browserErrors, [], 'Privacy page console contains errors');
console.log('privacy 360px: PASS', JSON.stringify(privacy));

await send('Runtime.evaluate', { expression: 'document.querySelector("[data-cookie-accept]").click()' });
await delay(450);
let cookieEvaluation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        stored: localStorage.getItem('globalEnglishCookieConsentV1'),
        state: document.querySelector('[data-cookie-banner]').dataset.state,
    })`,
});
assert.deepEqual(cookieEvaluation.result.value, { stored: 'all', state: 'closed' }, 'Cookie accept action failed');
await send('Runtime.evaluate', { expression: 'document.querySelector("[data-cookie-settings]").click()' });
await delay(80);
cookieEvaluation = await send('Runtime.evaluate', {
    returnByValue: true,
    expression: `({
        state: document.querySelector('[data-cookie-banner]').dataset.state,
        hidden: document.querySelector('[data-cookie-banner]').getAttribute('aria-hidden'),
    })`,
});
assert.deepEqual(cookieEvaluation.result.value, { state: 'open', hidden: 'false' }, 'Cookie settings did not reopen');
console.log('cookie interactions: PASS');

socket.close();
