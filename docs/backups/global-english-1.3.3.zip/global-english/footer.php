<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<footer class="site-footer">
    <div class="container site-footer__grid">
        <div class="footer-brand">
            <a class="brand" href="<?php echo esc_url(global_english_section_url('about')); ?>" aria-label="Global English, на главную">
                <span class="brand__copy"><strong>GLOBAL ENGLISH</strong><small>ШКОЛА ИНОСТРАННЫХ ЯЗЫКОВ</small></span>
            </a>
            <p>Помогаем заговорить на английском<br>и китайском языках уверенно и легко.</p>
            <div class="social-links" aria-label="Социальные сети">
                <a href="#" aria-label="ВКонтакте"><img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/vk.svg')); ?>" alt="" width="24" height="24"></a>
                <a href="#" aria-label="Telegram"><img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/telegram.svg')); ?>" alt="" width="24" height="24"></a>
                <a href="#" aria-label="Instagram"><img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/instagram.svg')); ?>" alt="" width="24" height="24"></a>
            </div>
        </div>
        <nav class="footer-column" aria-label="Навигация в подвале">
            <h2>Навигация</h2>
            <a href="<?php echo esc_url(global_english_section_url('about')); ?>">О школе</a><a href="<?php echo esc_url(global_english_section_url('courses')); ?>">Курсы</a><a href="<?php echo esc_url(global_english_section_url('method')); ?>">Методика</a><a href="<?php echo esc_url(global_english_section_url('benefits')); ?>">Преимущества</a><a href="<?php echo esc_url(global_english_section_url('reviews')); ?>">Отзывы</a><a href="<?php echo esc_url(global_english_section_url('contacts')); ?>">Контакты</a>
        </nav>
        <div class="footer-column">
            <h2>Курсы</h2>
            <a href="<?php echo esc_url(global_english_section_url('courses')); ?>">Английский для начинающих</a><a href="<?php echo esc_url(global_english_section_url('courses')); ?>">Английский для продолжающих</a><a href="<?php echo esc_url(global_english_section_url('courses')); ?>">Подготовка к IELTS / TOEFL</a><a href="<?php echo esc_url(global_english_section_url('courses')); ?>">Китайский язык</a>
        </div>
        <address class="footer-column">
            <h2>Контакты</h2>
            <a href="tel:+79991234567"><img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/phone.svg')); ?>" alt="" width="17" height="17">+7 (999) 123-45-67</a>
            <a href="mailto:info@globalenglish.ru"><img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/mail.svg')); ?>" alt="" width="17" height="17">info@globalenglish.ru</a>
            <p><img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/map-pin.svg')); ?>" alt="" width="17" height="17">г. Москва, ул. Примерная, 1</p>
        </address>
    </div>
    <div class="container site-footer__bottom">
        <p>© <?php echo esc_html(wp_date('Y')); ?> Global English. Все права защищены.</p>
        <div class="site-footer__legal">
            <a href="<?php echo esc_url(global_english_privacy_url()); ?>">Политика конфиденциальности</a>
            <button type="button" data-cookie-settings>Настройки cookie</button>
        </div>
    </div>
</footer>
<aside class="cookie-banner" data-cookie-banner data-state="open" role="region" aria-label="Настройки файлов cookie" aria-hidden="false">
    <div class="cookie-banner__copy">
        <strong>Мы используем cookie</strong>
        <p>Необходимые cookie помогают сайту работать. Дополнительные — запоминать ваш выбор. Подробнее в <a href="<?php echo esc_url(global_english_privacy_url()); ?>">политике конфиденциальности</a>.</p>
    </div>
    <div class="cookie-banner__actions">
        <button class="button button--secondary" type="button" data-cookie-essential>Только необходимые</button>
        <button class="button button--primary" type="button" data-cookie-accept>Принять</button>
    </div>
</aside>
<?php wp_footer(); ?>
</body>
</html>
