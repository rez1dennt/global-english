<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Онлайн-обучение английскому и китайскому языкам для детей и взрослых в школе Global English.">
    <link rel="icon" href="<?php echo esc_url(get_theme_file_uri('/assets/icons/favicon.svg')); ?>" type="image/svg+xml">
    <link rel="preload" href="<?php echo esc_url(get_theme_file_uri('/assets/fonts/manrope-cyrillic.woff2')); ?>" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="<?php echo esc_url(get_theme_file_uri('/assets/fonts/manrope-latin.woff2')); ?>" as="font" type="font/woff2" crossorigin>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main-content">Перейти к содержанию</a>
<header class="site-header" data-site-header>
    <div class="container site-header__inner">
        <a class="brand" href="<?php echo esc_url(global_english_section_url('about')); ?>" aria-label="Global English, на главную">
            <span class="brand__copy">
                <strong>GLOBAL ENGLISH</strong>
                <small>ШКОЛА ИНОСТРАННЫХ ЯЗЫКОВ</small>
            </span>
        </a>

        <button class="menu-toggle" type="button" aria-label="Открыть меню" aria-expanded="false" aria-controls="primary-navigation" data-menu-toggle>
            <span class="menu-toggle__label">Меню</span>
            <span class="menu-toggle__lines" aria-hidden="true"><i></i><i></i><i></i></span>
        </button>

        <nav class="primary-nav" id="primary-navigation" aria-label="Основная навигация" data-menu-panel>
            <a href="<?php echo esc_url(global_english_section_url('about')); ?>">О школе</a>
            <a href="<?php echo esc_url(global_english_section_url('courses')); ?>">Курсы</a>
            <a href="<?php echo esc_url(global_english_section_url('method')); ?>">Методика</a>
            <a href="<?php echo esc_url(global_english_section_url('benefits')); ?>">Преимущества</a>
            <a href="<?php echo esc_url(global_english_section_url('reviews')); ?>">Отзывы</a>
            <a href="<?php echo esc_url(global_english_section_url('contacts')); ?>">Контакты</a>
        </nav>

        <div class="site-header__actions">
            <a class="button button--primary button--small" href="<?php echo esc_url(global_english_section_url('contacts')); ?>"<?php if (is_front_page()) : ?> data-enrollment-modal-trigger aria-haspopup="dialog" aria-controls="enrollment-modal"<?php endif; ?>>Записаться на пробный урок</a>
            <a class="header-phone" href="tel:+79991234567">
                <img src="<?php echo esc_url(get_theme_file_uri('/assets/icons/phone.svg')); ?>" alt="" width="18" height="18">
                <span>+7 (999) 123-45-67</span>
            </a>
        </div>
    </div>
</header>
